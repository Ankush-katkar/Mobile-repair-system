package com.login.dao;

import java.io.*;  
import java.sql.*;  
import javax.servlet.ServletException;  
import javax.servlet.http.*;  
  
public class AddCustomer extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  

String u=request.getParameter("serial");          
String n=request.getParameter("firstname");  
String p=request.getParameter("contact");
String d=request.getParameter("imei");
String e=request.getParameter("email");  
String c=request.getParameter("company");
String r=request.getParameter("model");
String s=request.getParameter("gender");
String t=request.getParameter("dob");
          
try{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/mrs","root","admin");  
  
PreparedStatement ps=con.prepareStatement(  
"insert into addcustomer values(?,?,?,?,?,?,?,?,?)");  
ps.setString(1,u);  
ps.setString(2,n);  
ps.setString(3,p); 
ps.setString(4,d);
ps.setString(5,e);  
ps.setString(6,c);  
ps.setString(7,r);  
ps.setString(8,s);  
ps.setString(9,t);            
int i=ps.executeUpdate();  
if(i>0)  
out.print("Data uploaded succesfully..!");  
      
response.sendRedirect(request.getContextPath() + "/retrieve.jsp");          
}catch (Exception e2) {System.out.println(e2);}  
          
out.close();  
}  
  
}  